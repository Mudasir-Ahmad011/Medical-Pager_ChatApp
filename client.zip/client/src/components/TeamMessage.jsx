import React from 'react'

const TeamMessage = () => {
  return (
    <div>
      
    </div>
  )
}

export default TeamMessage
